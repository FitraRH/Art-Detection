import torch,  ultralytics, cv2
from ultralytics import YOLO

model = YOLO('best.pt')
# result = model.track(source=r'C:\Users\wphil\conda\anime art detection\test\images\0a33684655fda361a35d2612bfaf674a_jpg.rf.bee8bf010d7c6d068833241cade3bfdc.jpg'
#                      ,  conf=0.8, iou=0.5, show=True)

cap = cv2.VideoCapture(0)

while cap.isOpened():
    # Read a frame from the video
    success, frame = cap.read()

    if success:
        # Run YOLOv8 tracking on the frame, persisting tracks between frames
        results = model.track(frame, persist=True)

        # Visualize the results on the frame
        annotated_frame = results[0].plot()

        # Display the annotated frame
        cv2.imshow("YOLOv8 Tracking", annotated_frame)

        # Break the loop if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    else:
        # Break the loop if the end of the video is reached
        break

# Release the video capture object and close the display window
cap.release()
cv2.destroyAllWindows()
